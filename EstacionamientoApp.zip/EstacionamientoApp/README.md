# Estacionamiento - App Android

Proyecto Android que empaqueta la aplicación HTML de estacionamiento como una app instalable.

## Abrir
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Conecta un Android o usa un emulador.
4. Pulsa Run.
5. Para generar APK: Build > Build APK(s).

El HTML está en `app/src/main/assets/index.html`.
